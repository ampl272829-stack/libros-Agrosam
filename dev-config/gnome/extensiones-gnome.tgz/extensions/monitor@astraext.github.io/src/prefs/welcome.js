/*!
 * Copyright (C) 2023 Lju
 *
 * This file is part of Astra Monitor extension for GNOME Shell.
 * [https://github.com/AstraExt/astra-monitor]
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */
import Adw from 'gi://Adw';
import { gettext as _ } from 'resource:///org/gnome/Shell/Extensions/js/extensions/prefs.js';
import Utils from '../utils/utils.js';
import PrefsUtils from './prefsUtils.js';
export default class Welcome {
    constructor(prefs) {
        this.setupWelcome(prefs);
    }
    get page() {
        return this.welcome;
    }
    setupWelcome(_prefs) {
        this.welcome = new Adw.NavigationPage({
            title: _('Welcome'),
            tag: 'welcome',
        });
        const toolbar = new Adw.ToolbarView();
        const header = new Adw.HeaderBar();
        header.showTitle = false;
        toolbar.add_top_bar(header);
        const welcomePage = this.getWelcomePage();
        toolbar.set_content(welcomePage);
        this.welcome.set_child(toolbar);
    }
    getWelcomePage() {
        const visualizationPage = new Adw.PreferencesPage({});
        let group = new Adw.PreferencesGroup({ title: _('Dependencies') });
        const dependenciesGroup = group;
        let check = true;
        const asyncDependencyChecks = [
            {
                check: Utils.hasProcStat(),
                title: _('Cannot access /proc/stat: this extension will not work!'),
                icon: 'am-dialog-error-symbolic',
            },
            {
                check: Utils.hasProcCpuinfo(),
                title: _('Cannot access /proc/cpuinfo: this extension will not work!'),
                icon: 'am-dialog-error-symbolic',
            },
            {
                check: Utils.hasProcMeminfo(),
                title: _('Cannot access /proc/meminfo: this extension will not work!'),
                icon: 'am-dialog-error-symbolic',
            },
            {
                check: Utils.hasProcDiskstats(),
                title: _('Cannot access /proc/diskstats: this extension will not work!'),
                icon: 'am-dialog-error-symbolic',
            },
            {
                check: Utils.hasProcNetDev(),
                title: _('Cannot access /proc/net/dev: this extension will not work!'),
                icon: 'am-dialog-error-symbolic',
            },
            {
                check: Utils.hasCoresFrequency(),
                title: _('Cannot access /sys/devices/system/cpu/cpu*/cpufreq/scaling_cur_freq: some features will be disabled!'),
                icon: 'am-dialog-warning-symbolic',
            },
            {
                check: Utils.hasPsAsync(),
                title: _("Cannot access 'ps': this extension will not work!"),
                icon: 'am-dialog-error-symbolic',
            },
            {
                check: Utils.hasLscpuAsync(),
                title: _("'lscpu' not installed: some features will be disabled!"),
                icon: 'am-dialog-warning-symbolic',
            },
            {
                check: Utils.hasLspciAsync(),
                title: _("'lspci' not installed: some features will be disabled!"),
                icon: 'am-dialog-warning-symbolic',
            },
            {
                check: Utils.hasLsblkAsync(),
                title: _("'lsblk' not installed: some features will be disabled!"),
                icon: 'am-dialog-warning-symbolic',
            },
            {
                check: Utils.hasNethogsAsync(),
                title: _("'NetHogs' not installed: some optional features will be disabled!"),
                icon: 'am-dialog-warning-symbolic',
            },
            {
                check: Utils.hasIpAsync(),
                title: _("'iproute2' not installed: some features will be disabled!"),
                icon: 'am-dialog-warning-symbolic',
            },
            {
                check: Promise.all([Utils.hasIwAsync(), Utils.hasIwconfigAsync()]).then(results => results.some(result => result)),
                title: _("'iwconfig' and 'iw' not installed: install one of them to enable wireless network info!"),
                icon: 'am-dialog-warning-symbolic',
            },
            {
                check: Utils.hasIotopAsync(),
                title: _("'iotop' not installed: some optional features will be disabled!"),
                icon: 'am-dialog-warning-symbolic',
            },
            {
                check: Utils.getGPUsListAsync().then(async (gpus) => !gpus.some(gpu => Utils.isAmdGpu(gpu)) || (await Utils.hasAmdGpuTopAsync())),
                title: _("AMD GPU detected but 'amdgpu_top' not installed: some optional features will be disabled!"),
                icon: 'am-dialog-warning-symbolic',
            },
            {
                check: Utils.getGPUsListAsync().then(async (gpus) => !gpus.some(gpu => Utils.isNvidiaGpu(gpu)) ||
                    (await Utils.hasNvidiaSmiAsync())),
                title: _("NVidia GPU detected but 'nvidia-smi' not installed: some optional features will be disabled!"),
                icon: 'am-dialog-warning-symbolic',
            },
        ];
        if (!Utils.hasHwmon()) {
            check = false;
            PrefsUtils.addStatusLabel({
                title: _('Cannot access /sys/class/hwmon: sensors monitoring will not work!'),
            }, 'am-dialog-error-symbolic', group);
        }
        const statusLabel = PrefsUtils.addStatusLabel({ title: _('Checking GTop dependency...') }, 'am-dialog-info-symbolic', group);
        Utils.hasGTop()
            .then((GTopAvailable) => {
            if (!GTopAvailable) {
                statusLabel.row.title = _("'GTop' not installed, some optional features will be disabled! For a better experience and performance, install it from your package manager.");
                statusLabel.icon.set_from_icon_name('am-dialog-warning-symbolic');
            }
            else {
                statusLabel.row.title = _("'GTop' successfully detected and added to Data Sources list.");
                statusLabel.icon.set_from_icon_name('am-dialog-ok-symbolic');
            }
        })
            .catch((e) => {
            Utils.error('Error checking GTop dependency', e);
            statusLabel.row.title = _("'GTop' not installed, some optional features will be disabled! For a better experience and performance, install it from your package manager.");
            statusLabel.icon.set_from_icon_name('am-dialog-warning-symbolic');
        });
        Promise.all(asyncDependencyChecks.map(dependency => dependency.check))
            .then(results => {
            for (let i = 0; i < results.length; i++) {
                if (results[i])
                    continue;
                check = false;
                const dependency = asyncDependencyChecks[i];
                PrefsUtils.addStatusLabel({ title: dependency.title }, dependency.icon, dependenciesGroup);
            }
            if (check) {
                PrefsUtils.addStatusLabel({ title: _('All other dependencies are met!') }, 'am-dialog-ok-symbolic', dependenciesGroup);
            }
        })
            .catch((e) => {
            Utils.error('Error checking file dependencies', e);
        });
        visualizationPage.add(group);
        group = new Adw.PreferencesGroup({ title: _('Support Us') });
        PrefsUtils.addLinkRow({ title: '<span color="#FFB000">★ ' + _('Support us on Ko-Fi') + '</span>' }, 'https://ko-fi.com/astraext', group);
        PrefsUtils.addLinkRow({ title: '<span color="#FFB000">★ ' + _('Buy us a coffee') + '</span>' }, 'https://www.buymeacoffee.com/astra.ext', group);
        PrefsUtils.addLinkRow({ title: '<span color="#FFB000">★ ' + _('Become a patron') + '</span>' }, 'https://www.patreon.com/AstraExt', group);
        visualizationPage.add(group);
        return visualizationPage;
    }
}
